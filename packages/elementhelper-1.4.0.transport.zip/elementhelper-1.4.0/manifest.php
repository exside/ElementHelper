<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Element Helper - A MODx plugin for automatically creating elements
from static files without the manager.

Copyright (C) 2013  Rory Gibson

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or 
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

http://www.gnu.org/licenses/',
    'readme' => '--------------------
Extra: Element Helper
--------------------
Version: 1.4.0
 
Element Helper is a MODx Revolution plugin for automatically creating elements from static files without the MODx manager.

Github: https://github.com/roryg/ElementHelper

Usage:

To start using ElementHelper create a folder named elements in the core or assets directory of your MODx install and then create folders for chunks, snippets, templates and plugins within the elements folder (See the configuration section if you want to change where ElementHelper looks for your elements). Finally simply create your elements within those folders e.g. create a header.tpl file within the chunks folder or a get_menu.php file within your snippets folder. These elements will then automatically appear as elements in your MODx manager when you reload the manager or a frontend page.

Note: It is recommend that you only use this plugin during development of your site as it runs every time a page is loaded. You can disable it by simply going to the Elements tab in the manager and selecting \'Plugin Disabled\' on the \'element_helper\' plugin. As of ElementHelper v1.3.0 this is not an issue anymore as ElementHelper just runs if you\'re logged in as a member of a specific usergroup (default "Administrator") and then caches it\'s last run. ElementHelper now runs only when you change a file in the specified directories and should only have a minimal impact on the site performance.

Template Variables are managed using a JSON file, if you\'re using the default settings create a template_variables.json file within your elements folder. To create a simple text template variable add the following to your template_variables.json file:

[{
    "name": "example_text_tv",
    "caption": "Example Text TV",
    "type": "text"
}]

Expanding on that example you could add an image template variable that is assigned to two templates called \'home\' and \'standard_page\' with the following:

[{
    "name": "example_text_tv",
    "caption": "Example Text TV",
    "type": "text"

},{
    "name": "example_image_tv",
    "caption": "Example Image TV",
    "type": "Image",
    "template_access": ["home", "standard_page"]
}]

The following is a list of properties available for TVs

"type" The input type of this TV
"name" The name of this TV, and key by which it will be referenced in tags
"caption" The caption that will be used to display the name of this TV when on the Resource page
"description" A user-provided description of this TV
"category" The Category for this TV, or 0 if not in one
"locked" Whether or not this TV can only be edited by an Administrator
"elements" Default values for this TV
"rank" The rank of the TV when sorted and displayed relative to other TVs in its Category
"display" The output render type of this TV
"default_text" The default value of this TV if no other value is set
"properties" An array of default properties for this TV
"input_properties" An array of input properties related to the rendering of the input of this TV
"output_properties" An array of output properties related to the rendering of the output of this TV

Configuration/System Settings:

The following configuration options can be found by going to System Settings within your MODx manager and selecting the ElementHelper namespace.

Automatically Remove Elements: Allow ElementHelper to remove elements if you delete their source files (this will also remove TVs when you remove them from the TV JSON file).

Automatically Create Elements: Allow ElementHelper to create static elements/files from elements that are already existing in the database (but are not found in the elements physical directory/path). At the time this only works for Chunks, Snippets, Plugins and Templates.

Create Elements Categories: Comma separated list (with or without spaces) of categories for which ElementHelper should create the static files for. By default (if "Automatically Create Events" is set to true) ElementHelper just creates static files for elements that are in NO category, e.g. "0", if you want to specify categories but also include the elements without category then the first item of the list should be 0, eg. "0,FormIt,Articles".

Root Path: This is the path all the other relative element paths get appended to. Defaults to {base_path}. If you have your MODx core outsite of the webroot (which you should, see MODx advanced installation for more information) and you want to have your elements folder stored in the core directory, you need to change this to {core_path}. Additionally you could also specify another MODx path constant here, e.g. {assets_path} if you want to store your elements in the assets folder (then you don\'t need to specify assets/elements/chunks/ but just elements/chunks/ as the path/to/your/modxinstallation/assets/ is already prepended).

Chunk Path: Set the path to you chunk elements

Chunk Filetype: The filetype for chunks. Defaults to "tpl".

Plugin Path: Set the path to you plugin elements

Plugin Filetype: The filetype for plugins. Defaults to "php".

Plugin Add Events: Checks for plugin events behind the string defined in "Plugin Events Key" and attaches the plugin to these events automatically.

Plugin Check Events: Checks if the event(s) specified in the plugin files comment block is a valid one, e.g. exists in the current installations event table (this helps preventing the creation of unwanted new events due to typos etc.) and if not the event is ignored. Disable this if you use custom events.

Plugin Events Key: String to identify plugin events inside the opening comment block. Defaults to @Events.

Snippet Path: Set the path to you snippet elements

Snippet Filetype: The filetype for snippets. Defaults to "php".

Template Path: Set the path to you template elements

Template Filetype: The filetype for templates. Defaults to "tpl".

Template Variables JSON Path: Set the path to your template variable JSON file

Template Variable Access Control: Allow ElementHelper to give template variables access to the templates you set in the template variable json file. Note: Turning this on will remove template variable access from all templates unless specified in the template variable json file.

Element History: Keeps track of elements created with ElementHelper. You shouldn\'t ever need to edit this

Elements media source: Set a media source for your static elements

Description key: Set a key that will be used to find descriptions for your element files, defaults to @Description.

Default Description: Set a default description for elements created with ElementHelper

Usergroups: Set usergroups that ElementHelper should run for, defaults to Administrator

Debug: Activate/deactivate logging of debug messages into the MODx error log',
    'changelog' => 'Element Helper 1.4.0
====================================
- (exside) Added settings and functionality for automatic plugin event creation
- (exside) Added system settings and functionality to create static files/elements from already (in db) existing elements
- (exside) Added system settings for element filetypes
- (exside) Updated lexicon files (english/german)
- (exside) Added debug configuration to system settings and extended debugging information
- (exside) Made ElementHelper work with MODx advanced installations in combination with elements stored in the core folder
- (exside) Minor code refactoring and cleanup (class initialization, made function get_files() a class method, etc.)
- (exside) Big performance improvement through element history process refactoring + fix to make it really work
- (exside) ElementHelper cache files are now cleared when the site cache is emptied (by a member of the authorized usergroup)


Element Helper 1.3.2
====================================
- Fixed issue where deleting everything in the template_variables.json file prevented TVs from being removed in the manager.


Element Helper 1.3.1
====================================
- Fixed bug causing the Auto Remove Elements option to not work properly


Element Helper 1.3.0
====================================
- (exside) Added system setting elementhelper.usergroups to specify usergroups where ElementHelper should run, so page/manager are not slowed down by the plugin for users that cannot edit files in the target folders
- (exside) Added native modx caching to the plugin, so it only runs when a file in the target directories has changed, makes the plugin less obtrusive (by not checking all the files on every request) and makes it even possible to let it active on production sites (together with the usergroups feature)
- (exside) Updated lexicon files (english/german)


Element Helper 1.2.2
====================================
- Fixed error where TVs were trying to assign templates that didn\'t exist.


Element Helper 1.2.1
====================================
- (exside) Fixed problems with media source 1 not pointing to base path
- (exside) Added system setting "elementhelper.source" to specify which media source should be used for the static files
- (exside) Added german lexicon file / translation
- (exside) Added setting to make the description key customizable
- Added setting for default element descriptions


Element Helper 1.2.0
====================================
- Fixed various errors and bugs
- Made cache clearing more specific to avoid clearing unnecessary parts of the cache
- Added element history so only elements created with ElementHelper will be deleted when their files have been removed


Element Helper 1.1.1
====================================
- Fixed bug causing TVs to lose their settings
- Stopped Plugins from being auto deleted


Element Helper 1.1.0
====================================
- Fixed warnings/errors when trying to access directories that don\'t exist.
- Added OnManagerPageInit event to the plugin so elements update when a manager page is loaded.
- Added the ability to use categories on TVs
- Added setting to allow elements to be deleted from the manager when their files are deleted.


Element Helper 1.0.0
====================================
- Initial release',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2fbf2703912f96fcd5fb3d1384fbb4c1',
      'native_key' => 'elementhelper',
      'filename' => 'modNamespace/a32375f18694dd5124836f6ee614db5c.vehicle',
      'namespace' => 'elementhelper',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bf46ef106e02d7e35100cfeff83ef233',
      'native_key' => 1,
      'filename' => 'modCategory/44ecf3148e9bd1c532ab08c5c1968767.vehicle',
      'namespace' => 'elementhelper',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e9cba496087bbabc6c4999560414531',
      'native_key' => 'elementhelper.root_path',
      'filename' => 'modSystemSetting/9f088933238e5f3611cabe57a6fd92e2.vehicle',
      'namespace' => 'elementhelper',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '493c3b5c7115fd752a4a55a3da435191',
      'native_key' => 'elementhelper.chunk_path',
      'filename' => 'modSystemSetting/77e85e8e502526e24059fb969a1a6f01.vehicle',
      'namespace' => 'elementhelper',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2d1203b26c27bab2aeb210c9ee30fca',
      'native_key' => 'elementhelper.chunk_filetype',
      'filename' => 'modSystemSetting/a6f4ae4dbfb696aea3e09738a0f95898.vehicle',
      'namespace' => 'elementhelper',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20a7d8fad3997c9b649f67008282e765',
      'native_key' => 'elementhelper.template_path',
      'filename' => 'modSystemSetting/ce9c5069d5a86862fcf2fba93bc3e46c.vehicle',
      'namespace' => 'elementhelper',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a4c55fc305d4f5f0c7a73cb4186dfbe',
      'native_key' => 'elementhelper.template_filetype',
      'filename' => 'modSystemSetting/d496fc35b74cd2cdf41083604027d076.vehicle',
      'namespace' => 'elementhelper',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02487ba77f64ec74664c4d6eeb69a5ca',
      'native_key' => 'elementhelper.plugin_path',
      'filename' => 'modSystemSetting/ce57eb138d685e3ba3e15b4692122c2b.vehicle',
      'namespace' => 'elementhelper',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e42d4176e400e9e71ec29b66bf749cf3',
      'native_key' => 'elementhelper.plugin_filetype',
      'filename' => 'modSystemSetting/6dc7c46b5d63dfa94987b5faf6bc2b75.vehicle',
      'namespace' => 'elementhelper',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '507078fcdb10f79dfd4710e556a2bd98',
      'native_key' => 'elementhelper.plugin_events',
      'filename' => 'modSystemSetting/76cd0b4bbe1b21dc25db0f9ea73da01b.vehicle',
      'namespace' => 'elementhelper',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '966ef9b78e460036aff1fcc4606fcaeb',
      'native_key' => 'elementhelper.plugin_events_check',
      'filename' => 'modSystemSetting/a9ef2ff03e34f327bdd0843378b7cfaa.vehicle',
      'namespace' => 'elementhelper',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21b2943afaa6af7df7951280e03fa168',
      'native_key' => 'elementhelper.plugin_events_key',
      'filename' => 'modSystemSetting/04155d81556dd2f07bb1043160ab52e7.vehicle',
      'namespace' => 'elementhelper',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9af852462369abf21c5c21cd438a940b',
      'native_key' => 'elementhelper.snippet_path',
      'filename' => 'modSystemSetting/9b361b6f3c0e39416afd4b0b8ddb348a.vehicle',
      'namespace' => 'elementhelper',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef662fae9ac8abf5c307a5b0e06548a8',
      'native_key' => 'elementhelper.snippet_filetype',
      'filename' => 'modSystemSetting/83c62b6515d9ac06aa782115a53c84bb.vehicle',
      'namespace' => 'elementhelper',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd63af45b2ca550bfa4a7b21a30133c0f',
      'native_key' => 'elementhelper.tv_json_path',
      'filename' => 'modSystemSetting/1c5e0af5fdca38039f1ae06863915ed6.vehicle',
      'namespace' => 'elementhelper',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20abf33f2c08551e9b52512ff7f5dbe8',
      'native_key' => 'elementhelper.tv_access_control',
      'filename' => 'modSystemSetting/c33e6d282f082b762d67435166a820fa.vehicle',
      'namespace' => 'elementhelper',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12ee4c13e6d710589258cdf458a822f3',
      'native_key' => 'elementhelper.auto_remove_elements',
      'filename' => 'modSystemSetting/8c584463e0a602ae5a88cd6bcc33bc59.vehicle',
      'namespace' => 'elementhelper',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6705afe569e41d644c15664390a9e7b',
      'native_key' => 'elementhelper.auto_create_elements',
      'filename' => 'modSystemSetting/2611105e676e9afbb9e72adb938cbb81.vehicle',
      'namespace' => 'elementhelper',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e1aa2b66a747a5f0d593ab7e0196198',
      'native_key' => 'elementhelper.auto_create_elements_categories',
      'filename' => 'modSystemSetting/2abebb3d72a7ba38c28332bba86bfa1e.vehicle',
      'namespace' => 'elementhelper',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c73532ef1bd6dcf3f52c714fdf0858b6',
      'native_key' => 'elementhelper.element_history',
      'filename' => 'modSystemSetting/2c1c6aa087d14825ff3cd79149eac490.vehicle',
      'namespace' => 'elementhelper',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aad55e3cebfb4e96c4e7e99dcbef5ab6',
      'native_key' => 'elementhelper.source',
      'filename' => 'modSystemSetting/1b152bcf06cabc0cf7ae49a352a7ca57.vehicle',
      'namespace' => 'elementhelper',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5086efe8c069c52f3969aca8bb8f8f5',
      'native_key' => 'elementhelper.description_key',
      'filename' => 'modSystemSetting/99bdff3847c3ea8d0a919db4a342f596.vehicle',
      'namespace' => 'elementhelper',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb4331cb1385494826f045cbe0e60eab',
      'native_key' => 'elementhelper.description_default',
      'filename' => 'modSystemSetting/a76e391be57dac940210c8ddc4154e5e.vehicle',
      'namespace' => 'elementhelper',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81f39786068ee3aba605ce3b3ad4307d',
      'native_key' => 'elementhelper.usergroups',
      'filename' => 'modSystemSetting/2044d60cc034fcb316663764e1c12e6c.vehicle',
      'namespace' => 'elementhelper',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faba6188ca409b77432c6ae1357cc238',
      'native_key' => 'elementhelper.debug',
      'filename' => 'modSystemSetting/e759614382700aab14ebe1e6f261336c.vehicle',
      'namespace' => 'elementhelper',
    ),
  ),
);