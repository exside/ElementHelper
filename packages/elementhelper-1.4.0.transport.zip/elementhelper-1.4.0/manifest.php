<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Element Helper - A MODx plugin for automatically creating elements
from static files without the manager.

Copyright (C) 2013  Rory Gibson

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or 
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

http://www.gnu.org/licenses/',
    'readme' => 'ElementHelper for MODx Revolution
==================================

ElementHelper is a MODx plugin that automatically creates elements from static files without the need for the manager. It is especially helpful if you like to manage your elements without copying/pasting them to your editor and back to save them.

GitHub: https://github.com/roryg/ElementHelper

Version: 1.4.0


Usage
-----

### Note

It is recommend that you only use this plugin during development of your site as it runs every time a page is loaded. You can disable it by simply going to the Elements tab in the manager and selecting \'Plugin Disabled\' on the \'element_helper\' plugin. As of ElementHelper v1.3.0 this is not an issue anymore as ElementHelper just runs if you\'re logged in as a member of a specific usergroup (default "Administrator") and then caches it\'s last run. ElementHelper now runs only when you change a file in the specified directories and should only have a minimal impact on the site performance.

### Initial Setup

To start using ElementHelper create a folder named \'elements\' in the core or assets directory of your MODx installation and then create folders for chunks, snippets, templates and plugins within the elements folder (See the configuration section below if you want to change where ElementHelper looks for your elements). Finally simply create your elements within those folders e.g. create a header.tpl file within the chunks folder or a get_menu.php file within your snippets folder. These elements will then automatically appear as elements in your MODx manager when you reload the manager or a frontend page as a memer of the authorized usergroup.

### Chunks, Templates, Snippets, Plugins

Simply create your chunks, templates, snippets and plugins within their respective folders and they will automatically be created when you reload the manager or a frontend page.

### Template Variables

Template Variables are managed using a JSON file, if you\'re using the default settings create a template_variables.json file within your elements folder. To create a simple text template variable add the following to your template_variables.json file:

[{
    "name": "example_text_tv",
    "caption": "Example Text TV",
    "type": "text"
}]

Expanding on that example you could add an image template variable and a migx template variable that are assigned to two templates called \'home\' and \'standard_page\' with the following:

Note: The "Template Variable Access Control" setting must be set to "Yes" for the template_access feature to work. See the Configuration section for more information.

[{
    "name": "example_text_tv",
    "caption": "Example Text TV",
    "type": "text"

},{
    "name": "example_image_tv",
    "caption": "Example Image TV",
    "type": "image",
    "template_access": ["home", "standard_page"]
},{
    "name": "example_migx_tv",
    "caption": "Example MIGX TV",
    "type": "migx",
    "template_access": ["home", "standard_page"],
    "input_properties": {
        "formtabs": [{
            "caption": "Info", "fields": [{
                "field":"titles", "caption":"Title"
            }]
        }],
        "columns": [{
            "header": "Title", "width": "160", "sortable":"true", "dataIndex":"titles"
        }],
        "btntext": "Test Label",
        "autoResourceFolders": "false"
    }
}]

###### Template Variable Properties

* "type" The input type of this TV (all types should be lowercase)
* "name" The name of this TV, and key by which it will be referenced in tags
* "caption" The caption that will be used to display the name of this TV when on the Resource page
* "description" A user-provided description of this TV
* "category" The Category for this TV, or 0 if not in one
* "locked" Whether or not this TV can only be edited by an Administrator
* "elements" Default values for this TV
* "rank" The rank of the TV when sorted and displayed relative to other TVs in its Category
* "display" The output render type of this TV
* "default_text" The default value of this TV if no other value is set
* "properties" An array of default properties for this TV
* "input_properties" An array of input properties related to the rendering of the input of this TV
* "output_properties" An array of output properties related to the rendering of the output of this TV

Configuration / System Settings
-------------------------------

The following configuration options can be found by going to System Settings within your MODX manager and selecting the \'elementhelper\' namespace.
* Automatically Remove Elements: Allow ElementHelper to remove elements if you delete their source files (this will also remove TVs when you remove them from the TV JSON file).
* Automatically Create Elements: Allow ElementHelper to create static elements/files from elements that are already existing in the database (but are not found in the elements physical directory/path). At the time this only works for Chunks, Snippets, Plugins and Templates.
* Create Elements Categories: Comma separated list (with or without spaces) of categories for which ElementHelper should create the static files for. By default (if "Automatically Create Events" is set to true) ElementHelper just creates static files for elements that are in NO category, e.g. "0", if you want to specify categories but also include the elements without category then 0 also has to be included in the list, e.g. "0,FormIt,Articles".
* Root Path: This is the path all the other relative element paths get appended to. Defaults to {base_path}. If you have your MODx core outsite of the webroot (which you should, see MODx advanced installation for more information) and you want to have your \'elements\' folder stored in the core directory, you need to change this to {core_path}. Additionally you could also specify another MODx path constant here, e.g. {assets_path} if you want to store your elements in the assets folder (then you don\'t need to specify assets/elements/chunks/ but just elements/chunks/ as the path/to/your/modxinstallation/assets/ is already prepended).
* Chunk Path: Set the path to your chunk elements.
* Chunk Filetype: The filetype for chunks. Defaults to "tpl".
* Plugin Path: Set the path to your plugin elements.
* Plugin Filetype: The filetype for plugins. Defaults to "php".
* Plugin Add Events: Checks for system events behind the string defined in "Plugin Events Key" and attaches the plugin to these system events automatically.
* Plugin Check Events: Checks if the system event(s) specified in the plugin file comment block are valid ones, e.g. exists in the current MODx installations event table (this helps preventing the creation of unwanted new events due to typos etc.) and if not the event is ignored. This should not impose any problems with custom system events as it simply reads the database table and accecpts everything that is already in there.
* Plugin Events Key: String to identify plugin events inside the opening comment block. Defaults to @Events.
* Snippet Path: Set the path to your snippet elements.
* Snippet Filetype: The filetype for snippets. Defaults to "php".
* Template Path: Set the path to your template elements.
* Template Filetype: The filetype for templates. Defaults to "tpl".
* Template Variables JSON Path: Set the path to your template variable JSON file.
* Template Variable Access Control: Allow ElementHelper to give template variables access to the templates you set in the template variable JSON file. Note: Turning this on will remove template variable access from all templates unless specified in the template variable JSON file.
* Element History: Keeps track of elements created with ElementHelper. You shouldn\'t ever need to edit this.
* Elements media source: Set a media source for your static elements.
* Description key: Set a key that will be used to find descriptions for your element files, defaults to @Description.
* Default Description: Set a default description for elements created with ElementHelper.
* Usergroups: Set usergroups that ElementHelper should run for. Defaults to Administrator.
* Debug: Activate/deactivate logging of debug messages into the MODx error log.',
    'changelog' => 'Element Helper 1.4.0
====================================
- (JayCarney) input_properties fix and added support for MIGX TV creation
- (exside) Added settings and functionality for automatic plugin event creation
- (exside) Added system settings and functionality to create static files/elements from already (in db) existing elements
- (exside) Added system settings for element filetypes
- (exside) Updated lexicon files (english/german)
- (exside) Added debug configuration to system settings and extended debugging information
- (exside) Made ElementHelper work with MODx advanced installations in combination with elements stored in the core folder
- (exside) Minor code refactoring and cleanup (class initialization, made function get_files() a class method, etc.)
- (exside) Big performance improvement through element history process refactoring + fix to make it really work
- (exside) ElementHelper cache files are now cleared when the site cache is emptied (by a member of the authorized usergroup)


Element Helper 1.3.2
====================================
- Fixed issue where deleting everything in the template_variables.json file prevented TVs from being removed in the manager.


Element Helper 1.3.1
====================================
- Fixed bug causing the Auto Remove Elements option to not work properly


Element Helper 1.3.0
====================================
- (exside) Added system setting elementhelper.usergroups to specify usergroups where ElementHelper should run, so page/manager are not slowed down by the plugin for users that cannot edit files in the target folders
- (exside) Added native modx caching to the plugin, so it only runs when a file in the target directories has changed, makes the plugin less obtrusive (by not checking all the files on every request) and makes it even possible to let it active on production sites (together with the usergroups feature)
- (exside) Updated lexicon files (english/german)


Element Helper 1.2.2
====================================
- Fixed error where TVs were trying to assign templates that didn\'t exist.


Element Helper 1.2.1
====================================
- (exside) Fixed problems with media source 1 not pointing to base path
- (exside) Added system setting "elementhelper.source" to specify which media source should be used for the static files
- (exside) Added german lexicon file / translation
- (exside) Added setting to make the description key customizable
- Added setting for default element descriptions


Element Helper 1.2.0
====================================
- Fixed various errors and bugs
- Made cache clearing more specific to avoid clearing unnecessary parts of the cache
- Added element history so only elements created with ElementHelper will be deleted when their files have been removed


Element Helper 1.1.1
====================================
- Fixed bug causing TVs to lose their settings
- Stopped Plugins from being auto deleted


Element Helper 1.1.0
====================================
- Fixed warnings/errors when trying to access directories that don\'t exist.
- Added OnManagerPageInit event to the plugin so elements update when a manager page is loaded.
- Added the ability to use categories on TVs
- Added setting to allow elements to be deleted from the manager when their files are deleted.


Element Helper 1.0.0
====================================
- Initial release',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '83b1f207a484f37b1d7939f7d4f25669',
      'native_key' => 'elementhelper',
      'filename' => 'modNamespace/f3e52876a663b6354544d55103178abc.vehicle',
      'namespace' => 'elementhelper',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '18adad008b10baf732732bee188a115f',
      'native_key' => 1,
      'filename' => 'modCategory/6c0bd5f6d422fbc003eef42c1f4cc19b.vehicle',
      'namespace' => 'elementhelper',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2eff14de2bb94b8dd8ebff18af15afc',
      'native_key' => 'elementhelper.root_path',
      'filename' => 'modSystemSetting/e4f74ed9d281cf66829b406fc93558c5.vehicle',
      'namespace' => 'elementhelper',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37e4482cf2aaf4fc1d8f69a957b70e5f',
      'native_key' => 'elementhelper.chunk_path',
      'filename' => 'modSystemSetting/affbd65e13df7b561762e069b04d96b4.vehicle',
      'namespace' => 'elementhelper',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2f91c965e3c4f5570928a76c7e30950',
      'native_key' => 'elementhelper.chunk_filetype',
      'filename' => 'modSystemSetting/de6eea5c808c205d334499818326f291.vehicle',
      'namespace' => 'elementhelper',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b86ebf8fa69cb361d58f6883d368553e',
      'native_key' => 'elementhelper.template_path',
      'filename' => 'modSystemSetting/c69c333bef5467fc5e97265b8347ea58.vehicle',
      'namespace' => 'elementhelper',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '910d5b7b8403b0fe44df017f0c63d9c0',
      'native_key' => 'elementhelper.template_filetype',
      'filename' => 'modSystemSetting/dbbe20e4db2730ddcb765dadaab9219d.vehicle',
      'namespace' => 'elementhelper',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5fbf81f5a59d00f6ae1c2a7ea434f86',
      'native_key' => 'elementhelper.plugin_path',
      'filename' => 'modSystemSetting/2226ee848da56a584a9e830b24bc1858.vehicle',
      'namespace' => 'elementhelper',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e57e70b21483ccd56d83f896342d249',
      'native_key' => 'elementhelper.plugin_filetype',
      'filename' => 'modSystemSetting/e46043c8aa2fb2736c72eef08ad3dc87.vehicle',
      'namespace' => 'elementhelper',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbf68bb6bacde3e9d78efb8e88e303ba',
      'native_key' => 'elementhelper.plugin_events',
      'filename' => 'modSystemSetting/c2e6b8dc812db971f79424c8e9c75a94.vehicle',
      'namespace' => 'elementhelper',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88f8b14c7de9a482a0dd473e9b13b615',
      'native_key' => 'elementhelper.plugin_events_check',
      'filename' => 'modSystemSetting/7b5264baa8d4a528b6202a3837d42274.vehicle',
      'namespace' => 'elementhelper',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '801e14893d59367b336cd8526f491cf6',
      'native_key' => 'elementhelper.plugin_events_key',
      'filename' => 'modSystemSetting/0479999df102869f6a7db5e8d48a6054.vehicle',
      'namespace' => 'elementhelper',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '185241ff7d00aa752498ed028385d1a1',
      'native_key' => 'elementhelper.snippet_path',
      'filename' => 'modSystemSetting/0fea87a812c571fc3ed775bd75aacdd7.vehicle',
      'namespace' => 'elementhelper',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67250a278d908d4b1eeecf089e11b9c3',
      'native_key' => 'elementhelper.snippet_filetype',
      'filename' => 'modSystemSetting/85f047448861fe988f5ea5551ad0e96b.vehicle',
      'namespace' => 'elementhelper',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13c2fdadbc3574896223cd06d54710e6',
      'native_key' => 'elementhelper.tv_json_path',
      'filename' => 'modSystemSetting/dedf99448161a3c9811a65b10ce1e163.vehicle',
      'namespace' => 'elementhelper',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7527275d05de8aec2c16f598125d2264',
      'native_key' => 'elementhelper.tv_access_control',
      'filename' => 'modSystemSetting/eea78a66404e2743dac2f587949b48db.vehicle',
      'namespace' => 'elementhelper',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f92a69eed9d71e28c560e8a34e5bd62',
      'native_key' => 'elementhelper.auto_remove_elements',
      'filename' => 'modSystemSetting/4911a6cfc02eeb8103c8cdf04bee4238.vehicle',
      'namespace' => 'elementhelper',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd51eec69b63dd4a15c23e804389ff19',
      'native_key' => 'elementhelper.auto_create_elements',
      'filename' => 'modSystemSetting/7cb871e4b9d48906705361f1fff2d85c.vehicle',
      'namespace' => 'elementhelper',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '308e49c816a9dc444fda6b71cd599ff2',
      'native_key' => 'elementhelper.auto_create_elements_categories',
      'filename' => 'modSystemSetting/11e672d419ddc07103eed7f6f180e0a4.vehicle',
      'namespace' => 'elementhelper',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1666073af925e0b9bf42c46e6879557',
      'native_key' => 'elementhelper.element_history',
      'filename' => 'modSystemSetting/1a7cc407903d854c56332266dffd808b.vehicle',
      'namespace' => 'elementhelper',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fbc1750b2f407a406e21a007e4802d5',
      'native_key' => 'elementhelper.source',
      'filename' => 'modSystemSetting/b7e3651f81d94e33df98baee095fcc93.vehicle',
      'namespace' => 'elementhelper',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e418fe16674ea9a1d106629b2a94d70',
      'native_key' => 'elementhelper.description_key',
      'filename' => 'modSystemSetting/4a8047c6224ca65f48445dddd7abf787.vehicle',
      'namespace' => 'elementhelper',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db4fa74aa38f735a649df05c211be53d',
      'native_key' => 'elementhelper.description_default',
      'filename' => 'modSystemSetting/1a18d452bb8cfa3d2a8932d1cf003bf7.vehicle',
      'namespace' => 'elementhelper',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca61c3d9c3afed9f8367eb71822b93a8',
      'native_key' => 'elementhelper.usergroups',
      'filename' => 'modSystemSetting/e680956bf77e2faae65202a42de9dc0e.vehicle',
      'namespace' => 'elementhelper',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ac6c7cfa6e4cac298cdb97b3129216e',
      'native_key' => 'elementhelper.debug',
      'filename' => 'modSystemSetting/74de4d50545e270672b3ce23f75c6c1a.vehicle',
      'namespace' => 'elementhelper',
    ),
  ),
);