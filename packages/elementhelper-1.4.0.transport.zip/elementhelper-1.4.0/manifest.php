<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Element Helper - A MODx plugin for automatically creating elements
from static files without the manager.

Copyright (C) 2013  Rory Gibson

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or 
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

http://www.gnu.org/licenses/',
    'readme' => 'ElementHelper for MODx Revolution
==================================

ElementHelper is a MODx plugin that automatically creates elements from static files without the need for the manager. It is especially helpful if you like to manage your elements without copying/pasting them to your editor and back to save them.

GitHub: https://github.com/roryg/ElementHelper

Version: 1.4.0


Usage
-----

### Note

It is recommend that you only use this plugin during development of your site as it runs every time a page is loaded. You can disable it by simply going to the Elements tab in the manager and selecting \'Plugin Disabled\' on the \'element_helper\' plugin. As of ElementHelper v1.3.0 this is not an issue anymore as ElementHelper just runs if you\'re logged in as a member of a specific usergroup (default "Administrator") and then caches it\'s last run. ElementHelper now runs only when you change a file in the specified directories and should only have a minimal impact on the site performance.

### Initial Setup

To start using ElementHelper create a folder named \'elements\' in the core or assets directory of your MODx installation and then create folders for chunks, snippets, templates and plugins within the elements folder (See the configuration section below if you want to change where ElementHelper looks for your elements). Finally simply create your elements within those folders e.g. create a header.tpl file within the chunks folder or a get_menu.php file within your snippets folder. These elements will then automatically appear as elements in your MODx manager when you reload the manager or a frontend page as a memer of the authorized usergroup.

### Chunks, Templates, Snippets, Plugins

Simply create your chunks, templates, snippets and plugins within their respective folders and they will automatically be created when you reload the manager or a frontend page.

### Template Variables

Template Variables are managed using a JSON file, if you\'re using the default settings create a template_variables.json file within your elements folder. To create a simple text template variable add the following to your template_variables.json file:

[{
    "name": "example_text_tv",
    "caption": "Example Text TV",
    "type": "text"
}]

Expanding on that example you could add an image template variable and a migx template variable that are assigned to two templates called \'home\' and \'standard_page\' with the following:

Note: The "Template Variable Access Control" setting must be set to "Yes" for the template_access feature to work. See the Configuration section for more information.

[{
    "name": "example_text_tv",
    "caption": "Example Text TV",
    "type": "text"

},{
    "name": "example_image_tv",
    "caption": "Example Image TV",
    "type": "image",
    "template_access": ["home", "standard_page"]
},{
    "name": "example_migx_tv",
    "caption": "Example MIGX TV",
    "type": "migx",
    "template_access": ["home", "standard_page"],
    "input_properties": {
        "formtabs": [{
            "caption": "Info", "fields": [{
                "field":"titles", "caption":"Title"
            }]
        }],
        "columns": [{
            "header": "Title", "width": "160", "sortable":"true", "dataIndex":"titles"
        }],
        "btntext": "Test Label",
        "autoResourceFolders": "false"
    }
}]

###### Template Variable Properties

* "type" The input type of this TV (all types should be lowercase)
* "name" The name of this TV, and key by which it will be referenced in tags
* "caption" The caption that will be used to display the name of this TV when on the Resource page
* "description" A user-provided description of this TV
* "category" The Category for this TV, or 0 if not in one
* "locked" Whether or not this TV can only be edited by an Administrator
* "elements" Default values for this TV
* "rank" The rank of the TV when sorted and displayed relative to other TVs in its Category
* "display" The output render type of this TV
* "default_text" The default value of this TV if no other value is set
* "properties" An array of default properties for this TV
* "input_properties" An array of input properties related to the rendering of the input of this TV
* "output_properties" An array of output properties related to the rendering of the output of this TV

Configuration / System Settings
-------------------------------

The following configuration options can be found by going to System Settings within your MODX manager and selecting the \'elementhelper\' namespace.
* Automatically Remove Elements: Allow ElementHelper to remove elements if you delete their source files (this will also remove TVs when you remove them from the TV JSON file).
* Automatically Create Elements: Allow ElementHelper to create static elements/files from elements that are already existing in the database (but are not found in the elements physical directory/path). At the time this only works for Chunks, Snippets, Plugins and Templates.
* Create Elements Categories: Comma separated list (with or without spaces) of categories for which ElementHelper should create the static files for. By default (if "Automatically Create Events" is set to true) ElementHelper just creates static files for elements that are in NO category, e.g. "0", if you want to specify categories but also include the elements without category then 0 also has to be included in the list, e.g. "0,FormIt,Articles".
* Root Path: This is the path all the other relative element paths get appended to. Defaults to {base_path}. If you have your MODx core outsite of the webroot (which you should, see MODx advanced installation for more information) and you want to have your \'elements\' folder stored in the core directory, you need to change this to {core_path}. Additionally you could also specify another MODx path constant here, e.g. {assets_path} if you want to store your elements in the assets folder (then you don\'t need to specify assets/elements/chunks/ but just elements/chunks/ as the path/to/your/modxinstallation/assets/ is already prepended).
* Chunk Path: Set the path to your chunk elements.
* Chunk Filetype: The filetype for chunks. Defaults to "tpl".
* Plugin Path: Set the path to your plugin elements.
* Plugin Filetype: The filetype for plugins. Defaults to "php".
* Plugin Add Events: Checks for system events behind the string defined in "Plugin Events Key" and attaches the plugin to these system events automatically.
* Plugin Check Events: Checks if the system event(s) specified in the plugin file comment block are valid ones, e.g. exists in the current MODx installations event table (this helps preventing the creation of unwanted new events due to typos etc.) and if not the event is ignored. This should not impose any problems with custom system events as it simply reads the database table and accecpts everything that is already in there.
* Plugin Events Key: String to identify plugin events inside the opening comment block. Defaults to @Events.
* Snippet Path: Set the path to your snippet elements.
* Snippet Filetype: The filetype for snippets. Defaults to "php".
* Template Path: Set the path to your template elements.
* Template Filetype: The filetype for templates. Defaults to "tpl".
* Template Variables JSON Path: Set the path to your template variable JSON file.
* Template Variable Access Control: Allow ElementHelper to give template variables access to the templates you set in the template variable JSON file. Note: Turning this on will remove template variable access from all templates unless specified in the template variable JSON file.
* Element History: Keeps track of elements created with ElementHelper. You shouldn\'t ever need to edit this.
* Elements media source: Set a media source for your static elements.
* Description key: Set a key that will be used to find descriptions for your element files, defaults to @Description.
* Default Description: Set a default description for elements created with ElementHelper.
* Usergroups: Set usergroups that ElementHelper should run for. Defaults to Administrator.
* Debug: Activate/deactivate logging of debug messages into the MODx error log.',
    'changelog' => 'Element Helper 1.4.0
====================================
- (JayCarney) input_properties fix and added support for MIGX TV creation
- (exside) Added settings and functionality for automatic plugin event creation
- (exside) Added system settings and functionality to create static files/elements from already (in db) existing elements
- (exside) Added system settings for element filetypes
- (exside) Updated lexicon files (english/german)
- (exside) Added debug configuration to system settings and extended debugging information
- (exside) Made ElementHelper work with MODx advanced installations in combination with elements stored in the core folder
- (exside) Minor code refactoring and cleanup (class initialization, made function get_files() a class method, etc.)
- (exside) Big performance improvement through element history process refactoring + fix to make it really work
- (exside) ElementHelper cache files are now cleared when the site cache is emptied (by a member of the authorized usergroup)


Element Helper 1.3.2
====================================
- Fixed issue where deleting everything in the template_variables.json file prevented TVs from being removed in the manager.


Element Helper 1.3.1
====================================
- Fixed bug causing the Auto Remove Elements option to not work properly


Element Helper 1.3.0
====================================
- (exside) Added system setting elementhelper.usergroups to specify usergroups where ElementHelper should run, so page/manager are not slowed down by the plugin for users that cannot edit files in the target folders
- (exside) Added native modx caching to the plugin, so it only runs when a file in the target directories has changed, makes the plugin less obtrusive (by not checking all the files on every request) and makes it even possible to let it active on production sites (together with the usergroups feature)
- (exside) Updated lexicon files (english/german)


Element Helper 1.2.2
====================================
- Fixed error where TVs were trying to assign templates that didn\'t exist.


Element Helper 1.2.1
====================================
- (exside) Fixed problems with media source 1 not pointing to base path
- (exside) Added system setting "elementhelper.source" to specify which media source should be used for the static files
- (exside) Added german lexicon file / translation
- (exside) Added setting to make the description key customizable
- Added setting for default element descriptions


Element Helper 1.2.0
====================================
- Fixed various errors and bugs
- Made cache clearing more specific to avoid clearing unnecessary parts of the cache
- Added element history so only elements created with ElementHelper will be deleted when their files have been removed


Element Helper 1.1.1
====================================
- Fixed bug causing TVs to lose their settings
- Stopped Plugins from being auto deleted


Element Helper 1.1.0
====================================
- Fixed warnings/errors when trying to access directories that don\'t exist.
- Added OnManagerPageInit event to the plugin so elements update when a manager page is loaded.
- Added the ability to use categories on TVs
- Added setting to allow elements to be deleted from the manager when their files are deleted.


Element Helper 1.0.0
====================================
- Initial release',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '89fd5fe12d6edba095799ca415ae6015',
      'native_key' => 'elementhelper',
      'filename' => 'modNamespace/b34155a526de38770d93b8a7e47fc3e6.vehicle',
      'namespace' => 'elementhelper',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c87995cbec18f25077686d9746555a8b',
      'native_key' => 1,
      'filename' => 'modCategory/23bc999f9aec8d88d2e5949f0d5a7f29.vehicle',
      'namespace' => 'elementhelper',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3705de73a54bc22a8dd44b75f2aafe6',
      'native_key' => 'elementhelper.root_path',
      'filename' => 'modSystemSetting/82c3c3cf0f5dd2a26befebba028a5bf4.vehicle',
      'namespace' => 'elementhelper',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4af5c00fe9200816e3b96303c2f7112d',
      'native_key' => 'elementhelper.chunk_path',
      'filename' => 'modSystemSetting/7c33423806375dae875c9be0a8f2178a.vehicle',
      'namespace' => 'elementhelper',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47df39870f6780f03e0d5e6490812c5f',
      'native_key' => 'elementhelper.chunk_filetype',
      'filename' => 'modSystemSetting/dece5717b91cef92833c7000231f0c5a.vehicle',
      'namespace' => 'elementhelper',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbe427018b403e59ab84f776f2d5c102',
      'native_key' => 'elementhelper.template_path',
      'filename' => 'modSystemSetting/dfa5dd5e51fec3c3d10b1273d96b3b7d.vehicle',
      'namespace' => 'elementhelper',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '434c219b5191c3b437b0ccefb5f33b50',
      'native_key' => 'elementhelper.template_filetype',
      'filename' => 'modSystemSetting/be0edcc070b6e3296e672264dad44118.vehicle',
      'namespace' => 'elementhelper',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64260b3ccfbe72447bd3a5be2fd9a855',
      'native_key' => 'elementhelper.plugin_path',
      'filename' => 'modSystemSetting/a25a222e603230ed5e9570a69cf313cd.vehicle',
      'namespace' => 'elementhelper',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a38e2c82c0646188ca7ac82856ec7bc',
      'native_key' => 'elementhelper.plugin_filetype',
      'filename' => 'modSystemSetting/c04828f06b93286028cc0282f4a2403a.vehicle',
      'namespace' => 'elementhelper',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8a552bc64b017fe5e3fc58a7b700b6f',
      'native_key' => 'elementhelper.plugin_events',
      'filename' => 'modSystemSetting/857136ed18a87837cc2130dd657c96cf.vehicle',
      'namespace' => 'elementhelper',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85c28bd0770e71ed404720ae034b74ac',
      'native_key' => 'elementhelper.plugin_events_check',
      'filename' => 'modSystemSetting/fd227b813fa1f8810b67d8a59377f4d9.vehicle',
      'namespace' => 'elementhelper',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32e2b97a5595be2d9e6f660661219e65',
      'native_key' => 'elementhelper.plugin_events_key',
      'filename' => 'modSystemSetting/cd1f1a04759e2945174f91d575793400.vehicle',
      'namespace' => 'elementhelper',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f90828facb7ad2a887ff379e0f8f556a',
      'native_key' => 'elementhelper.snippet_path',
      'filename' => 'modSystemSetting/63816b812f0d37e7fed580d8f80d4cb3.vehicle',
      'namespace' => 'elementhelper',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08caf4dae354e061a0dd0edcb02991b3',
      'native_key' => 'elementhelper.snippet_filetype',
      'filename' => 'modSystemSetting/320d9cccd3f883b79b09db684e6ecd0d.vehicle',
      'namespace' => 'elementhelper',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b858f2e7fb9b391543a1bdf587796239',
      'native_key' => 'elementhelper.tv_json_path',
      'filename' => 'modSystemSetting/10503ec45941fe2341a86445b634957a.vehicle',
      'namespace' => 'elementhelper',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a40b7e288b0a952bb5c96effca04a534',
      'native_key' => 'elementhelper.tv_access_control',
      'filename' => 'modSystemSetting/81592625119170040c85babd66804126.vehicle',
      'namespace' => 'elementhelper',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13cf1da184a86db98d0d58f22f003e81',
      'native_key' => 'elementhelper.auto_remove_elements',
      'filename' => 'modSystemSetting/95ecfb4c49c24cbc140e40f9d29f4597.vehicle',
      'namespace' => 'elementhelper',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9fc86faa3d06f5faa67fe0cd4739789',
      'native_key' => 'elementhelper.auto_create_elements',
      'filename' => 'modSystemSetting/a075b4c8d7d050327349092f3085b535.vehicle',
      'namespace' => 'elementhelper',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec631fc621a01d5304893d6c62505215',
      'native_key' => 'elementhelper.auto_create_elements_categories',
      'filename' => 'modSystemSetting/3a54f71e631762fc128f1a2c742e271f.vehicle',
      'namespace' => 'elementhelper',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83a357f51d81c2a0f6eece1aad45682c',
      'native_key' => 'elementhelper.element_history',
      'filename' => 'modSystemSetting/049c268c393b603a1fc3821356aab16b.vehicle',
      'namespace' => 'elementhelper',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '096e3fc5af77bc220fb59448031ff103',
      'native_key' => 'elementhelper.source',
      'filename' => 'modSystemSetting/e0af840e5b2fe38fcf11a3af5598ebef.vehicle',
      'namespace' => 'elementhelper',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d7725422bb8feda658be2045ed081b1',
      'native_key' => 'elementhelper.description_key',
      'filename' => 'modSystemSetting/357a229ffa5f0ff309705a0c35a34069.vehicle',
      'namespace' => 'elementhelper',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '639a304a47ccf4a3fa348bd97a17cf5d',
      'native_key' => 'elementhelper.description_default',
      'filename' => 'modSystemSetting/a8e2127136f3a31b4942100ea2dd8dd2.vehicle',
      'namespace' => 'elementhelper',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cbd1262e5957287b460134536131873',
      'native_key' => 'elementhelper.usergroups',
      'filename' => 'modSystemSetting/e10e072ba768c13983d5710e85a4a828.vehicle',
      'namespace' => 'elementhelper',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27c24ab5dacbe47818ca9e66fc32eeac',
      'native_key' => 'elementhelper.debug',
      'filename' => 'modSystemSetting/85376543e1dab72c0e5e6550d7eb01c0.vehicle',
      'namespace' => 'elementhelper',
    ),
  ),
);